package mdClone2;

import org.json.simple.parser.JSONParser;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
public class ReadJsonFile {
	
	public static void main(String[] args) 
    {
        //JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();
        
        ArrayList<Data> dataListToCheck = new ArrayList<Data>();
        ArrayList<HeatMap> heatMapList = new ArrayList<HeatMap>();
        
         
        try (FileReader reader = new FileReader("jsonData.json"))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);
 
            JSONArray dataList = (JSONArray) obj;
            System.out.println(dataList);
            
            dataList.forEach(jsonData -> parseEmployeeObject((JSONObject) jsonData, dataListToCheck));
            
            //heatMapList = dataListToCheck.stream().filter(data :: mapDataListToCheck(data.))
            
            for (int i = 0; i < dataListToCheck.size(); i++) {
            	HeatMap heatMap = new HeatMap();
            	heatMap.setColor(mapDataListToCheck(dataListToCheck.get(i)));
            	heatMapList.add(heatMap);
			}
 
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
	
	private static String mapDataListToCheck(Data data){
		if (data.getValue() >=0 && data.getValue() <25) {
			return "green";
		}
		else if (data.getValue() >= 25 && data.getValue() <75) {
			return "yellow";
		}
		else {
			return "red";
		}	
	}
	
	private static void parseEmployeeObject(JSONObject jsonData, ArrayList<Data> dataListToCheck) {
		Data data = new Data();
    	//JSONObject dataObj = (JSONObject) dataList.get(i);
    	String timestamp = (String) jsonData.get("timestamp");
    	String value = (String) jsonData.get("value");
    	if (!value.equals("null") && Integer.valueOf(value)>=0 && Integer.valueOf(value) <=100) {
    		try {
    			data.setTimestamp(convertToDate(timestamp));
    		} catch (ParseException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
        	data.setValue(Integer.valueOf(value));
        	dataListToCheck.add(data);
		}
    	
	}

	private static Date convertToDate(String receivedDate) throws ParseException{
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date date = null;
		try {
			date = formatter.parse(receivedDate);
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return date;
	}
	
	

}
