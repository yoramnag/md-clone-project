package mdClone2;

public class HeatMap {
	
	private String color;

	public HeatMap() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HeatMap(String color) {
		super();
		this.color = color;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	

}
